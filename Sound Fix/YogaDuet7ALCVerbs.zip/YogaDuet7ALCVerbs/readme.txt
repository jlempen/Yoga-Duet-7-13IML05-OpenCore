YogaDuet7ALCVerbs daemon for the Lenovo Yoga Duet 7 13IML05
(c) 2022 Jürg Lempen - info@jlempen.com

The purpose of this daemon is to check every 20 seconds if audio is playing on the system and send specific ALC verb commands to the Realtek ALC287 sound chip to wake it up from standby only if audio is indeed playing. It may take a few seconds for the daemon to wake up the sound chip once audio is playing. The system overhead should be negligible.

The check interval may be adjusted by changing the value in seconds of the "StartInterval" parameter in the file "com.jlempen.YogaDuet7ALCVerbs.plist".

This daemon requires inserting "alcverbs=1" in the boot-args of your OpenCore config.plist file and setting up AppleALC.kext to use the layout 11.

To install the daemon, run "./install_daemon.sh"

To remove the daemon, run "./uninstall_daemon.sh"
