#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null && pwd )"

# remove the old YogaDuet7ALCVerbs
echo "Unloading older instance of the daemon ..."
launchctl unload /Library/LaunchDaemons/com.jlempen.YogaDuet7ALCVerbs.plist 2>/dev/null
echo "Removing older instance of the daemon ..."
sudo rm /Library/LaunchDaemons/com.jlempen.YogaDuet7ALCVerbs.plist 2>/dev/null
sudo rm /Library/Application\ Support/YogaDuet7ALCVerbs/YogaDuet7ALCVerbs.sh 2>/dev/null
sudo rm -rf /Library/Application\ Support/YogaDuet7ALCVerbs 2>/dev/null
sudo rm /usr/local/bin/alc-verb 2>/dev/null

# install the alc-verb executable
echo "Installing the alc-verb executable in /usr/local/bin/ ..."
sudo mkdir -p /usr/local/bin/
sudo chmod -R 755 /usr/local/bin/
sudo cp $DIR/alc-verb /usr/local/bin/
sudo chmod 755 /usr/local/bin/alc-verb
sudo chown root:wheel /usr/local/bin/alc-verb
sudo xattr -d com.apple.quarantine /usr/local/bin/alc-verb 2>/dev/null

# install the YogaDuet7ALCVerbs.sh script
echo "Installing the YogaDuet7ALCVerbs.sh script in /Library/Application\ Support/YogaDuet7ALCVerbs/ ..."
sudo mkdir -p /Library/Application\ Support/YogaDuet7ALCVerbs/
sudo chmod -R 755 /Library/Application\ Support/YogaDuet7ALCVerbs/
sudo cp $DIR/YogaDuet7ALCVerbs.sh /Library/Application\ Support/YogaDuet7ALCVerbs/
sudo chmod 755 /Library/Application\ Support/YogaDuet7ALCVerbs/YogaDuet7ALCVerbs.sh
sudo chown root:admin /Library/Application\ Support/YogaDuet7ALCVerbs/YogaDuet7ALCVerbs.sh
sudo xattr -d com.apple.quarantine /Library/Application\ Support/YogaDuet7ALCVerbs/YogaDuet7ALCVerbs.sh 2>/dev/null

# install the com.jlempen.YogaDuet7ALCVerbs.plist daemon
echo "Installing the com.jlempen.YogaDuet7ALCVerbs.plist daemon in /Library/LaunchDaemons/ ..."
sudo cp $DIR/com.jlempen.YogaDuet7ALCVerbs.plist /Library/LaunchDaemons
sudo chmod 644 /Library/LaunchDaemons/com.jlempen.YogaDuet7ALCVerbs.plist
sudo chown root:wheel /Library/LaunchDaemons/com.jlempen.YogaDuet7ALCVerbs.plist
sudo xattr -d com.apple.quarantine /Library/LaunchDaemons/com.jlempen.YogaDuet7ALCVerbs.plist 2>/dev/null

# load the com.jlempen.YogaDuet7ALCVerbs.plist daemon
echo "Loading the com.jlempen.YogaDuet7ALCVerbs.plist daemon ..."
launchctl load /Library/LaunchDaemons/com.jlempen.YogaDuet7ALCVerbs.plist

echo "YogaDuet7ALCVerbs daemon installed successfully."