#!/bin/bash

# unload the YogaDuet7ALCVerbs.plist daemon
echo "Unloading the YogaDuet7ALCVerbs daemon ..."
launchctl unload /Library/LaunchDaemons/com.jlempen.YogaDuet7ALCVerbs.plist 2>/dev/null

# delete the files
echo "Removing the files ..."
sudo rm /Library/LaunchDaemons/com.jlempen.YogaDuet7ALCVerbs.plist 2>/dev/null
sudo rm /Library/Application\ Support/YogaDuet7ALCVerbs/YogaDuet7ALCVerbs.sh 2>/dev/null
sudo rm -rf /Library/Application\ Support/YogaDuet7ALCVerbs 2>/dev/null
sudo rm /usr/local/bin/alc-verb 2>/dev/null

echo "YogaDuet7ALCVerbs daemon uninstalled successfully."
