#!/bin/sh

/usr/local/bin/AudioSwitcher -s "Speaker (Analog)"
/usr/local/bin/AudioSwitcher -s "Speaker (Analog)" -t system
